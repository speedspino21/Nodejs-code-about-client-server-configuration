let http = require("http");
let httpProxy = require('http-proxy');
let net = require('net');

let port = { server: 9000, client: 8000 };
let clientList = [];


// Create http server
const server = http.createServer((req, res) => {
    console.log(`----------Client connected, forward to client.js by socket connection -------`)

    // Emit to connected client
    clientList[0].emit('proxyData', JSON.stringify(req.headers), (resData) => {
        if(resData.data){
            res.writeHead(200, { 'Content-Type': 'text/html' });
            //res.write('request successfully proxied!' + '\n' + JSON.stringify(resData, true, 2));
            console.log(resData.data);
            //res.end();
            res.write(resData.data)
            res.end()
        }else{
            res.write('Error');
            res.end()
        }

    });


}).listen(port.server, ()=>{
    console.log('  Server is running at http://localhost:%d', port.server);
    console.log('  Press CTRL-C to stop\n');
});

// Init socket instance
const io = require('socket.io')(server);

// Listen on connection
io.on('connection', client => {
    console.log(`Client connected: SocketID = ${client.id}`);

    // Push to client list
    clientList.push(client);

    // Emit info to client
    client.emit('connectedInfo', {id: client.id});

    // remove client from list
    client.on('disconnect', () => {
        console.log(`Client disconnected: SocketID = ${client.id}`);
        clientList = clientList.filter((item)=>{
            return item.id === client.id
        })
    });
});
