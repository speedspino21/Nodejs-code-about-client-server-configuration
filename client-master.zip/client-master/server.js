let http = require("http");
let https = require('https');
let request = require("request");

// Keep id for each socket connection
let id = null;

// Connect to server by socket connection
let socketClient = require('socket.io-client')('http://localhost:9000');

socketClient.on('connect', function(data){
    console.log('*Connected to server*')


    socketClient.on('connectedInfo', function(data){
        console.log('------------------- ID --------------------');
        id = data.id;
        console.log(id)
        console.log('-------------------------------------------');
    });


    socketClient.on('proxyData', async function(data, res){
        try{
            console.log('--------------- Proxy Data ----------------');
            let parseData = JSON.parse(data);
            console.log(parseData.host);
            console.log('-------------------------------------------');
            let rs = await getScript(parseData.host) //await getScript(parseData.host);
            res({id, data: rs});
        }catch (e) {
            res({id, data: e.toString()});
        }

    });
    socketClient.on('disconnect', function(){});
});


const getScript = (url) => {
    return new Promise((resolve, reject) => {
        if (url.toString().indexOf("http") === -1 && url.toString().indexOf("https") === -1) {
            if(url.toString().indexOf("www") === -1){
                url='www.'+url
            }
            url='https://'+url
        }

        request({uri: url},
            function(error, response, body) {
                resolve(body);
            });
    });
};
